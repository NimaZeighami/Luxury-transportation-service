import React from "react";

const Home = () => {
  return (
    <div>
      <iframe
      title="   "
        src="https://dignitylimo.com/"
        style={{
          border: "none",
          width: "100vw",
          height: "100vh",
          position: "fixed",
          top: 0,
          left: 0,
          zIndex: 9999,
        }}
        allowFullScreen
      />
    </div>
  );
};

export default Home;
